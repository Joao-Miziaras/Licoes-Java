/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projeto.po;

/**
 *
 * @author Aluno
 */
public class Aluno {
    /*
    modificadores de acessos
        default
        private
        public
        protected
    */
    
    private String ra;
    private String nome;
    private Double ac1 = 0.0;
    private Double ac2 = 0.0;
    public String getRa(){
        return ra;
    }
    public void setRa(String ra){
        this.ra = ra;
    }

    public String getNome() {
        return nome;
    }

    public Double getAc1() {
        return ac1;
    }

    public Double getAc2() {
        return ac2;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setAc1(Double ac1) {
        if (isNotaValida(ac1)) {
            this.ac1 = ac1;            
        }
    }

    public void setAc2(Double ac2) {
        if (isNotaValida(ac2)) {  
            this.ac2 = ac2;
        }
    }
    private Boolean isNotaValida(Double nota){
        return nota >=0.0 && nota <= 10.0;
    }
    
    Double obterMedia(Double ac1, Double ac2){
        return (ac1 + ac2)/2;
    }
    
}
