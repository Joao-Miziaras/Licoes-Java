package com.mycompany.projeto.po;


public class App {
    public static void main(String[] args) {
        ContaCorrente conta1 = new ContaCorrente();
//        ContaCorrente conta2 = new ContaCorrente();
//        Aluno aluno1 = new Aluno();
//        aluno1.setNome("Diego");
//        aluno1.setAc1(6.0);
//        aluno1.setAc2(3.0);
//        
//        System.out.println("RA " + aluno1.getRa() );
//        System.out.println("nome " + aluno1.getNome());
//        System.out.println("nota 1 " + aluno1.getAc1());
//        System.out.println("nota 2 " + aluno1.getAc2());
        conta1.setNumero("#001");
        conta1.setTitular("Titular");
        conta1.setSaldo(0.0);
        conta1.depositar(100.0);
        System.out.println(conta1.getSaldo());
        conta1.sacar(10.0);
        System.out.println(conta1.getSaldo());

    }
}
