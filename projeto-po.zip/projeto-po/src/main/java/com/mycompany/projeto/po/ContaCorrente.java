package com.mycompany.projeto.po;

public class ContaCorrente {
    private Double saldo;
    private String titular;
    private String numero;

    public ContaCorrente(String titular, String numero) {
        this.titular = titular;
        this.numero = numero;
        this.saldo = 0.0;
    }
    public ContaCorrente(){}
    
    
    public Double getSaldo() {
        return saldo;
    }

    public String getTitular() {
        return titular;
    }

    public String getNumero() {
        return numero;
    }

    public void setSaldo(Double saldo) {
        this.saldo = saldo;
    }
    
    public void depositar(Double saldo) {
        if (saldo>0) {
            this.saldo += saldo; 
        } else{
            System.out.println("erro");
        }
    }
        public void sacar(Double saque) {
        if (saque>0 && saque<= this.saldo) {
            this.saldo -= saque; 
        } else{
            System.out.println("erro");
        }
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }
    
    
}
