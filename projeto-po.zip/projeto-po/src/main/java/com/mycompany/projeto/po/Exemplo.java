/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projeto.po;

/**
 *
 * @author aluno
 */
public class Exemplo {
    public static void main(String[] args) {
    ContaCorrente conta = new ContaCorrente("tite", "001");
    ContaCorrente conta2 = new ContaCorrente();

    
        System.out.println(conta.getTitular() + conta.getNumero());
        System.out.println(conta2.getTitular() + conta2.getNumero());
    
        
    }
}
